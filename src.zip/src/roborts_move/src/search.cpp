#include"ros/ros.h" 
#include "nav_msgs/Path.h"
#include "nav_msgs/OccupancyGrid.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/PointStamped.h"
#include"geometry_msgs/Twist.h"
#include "tf/tf.h"
#include <tf/transform_listener.h>
#include<vector>
#include<algorithm>
#include<deque>
#include<math.h>
using namespace std;

#define map_width 163    //地图png的宽
#define map_height  103  //地图png的高
#define resolution 0.05  //地图的分辨率 单位m
#define P_Parameter 0.6 //方向校正系数
#define a_Parameter  0.5  //加速度
#define max_vel  3  //最大速度
#define dec_len  1  //最大减速距离
#define origin_x 0  //地图原点在map坐标系下的x坐标
#define origin_y 0 //地图原点在map坐标系下的y坐标

void costmapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg);
int impactTest(geometry_msgs::PointStamped map_point_start,vector<geometry_msgs::PoseStamped> global_Path_fun,double length);
void pubVel();
void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg);
void pathCallback(const nav_msgs::Path::ConstPtr& msg);
void velCallback(const geometry_msgs::Twist::ConstPtr& msg);

ros::Publisher vel_pub;  //速度发布器
vector<geometry_msgs::PoseStamped> global_Path_;  //全局规划路径
geometry_msgs::PoseStamped current_pose;  //当前位置
geometry_msgs::Twist current_vel_back; //当前速度
nav_msgs::OccupancyGrid global_costmap;   //全局代价地图

float turnTest(){    //返回拐弯的角度值
        return 0;
}

int impactTest(geometry_msgs::PointStamped map_point_start,vector<geometry_msgs::PoseStamped> global_Path_fun,double length){   //返回-1表示最短追踪点也无法满足有求，大于1时为满足要求的追踪点位置
    int aim = -1;
    double aim_len;
    int impact_flag; //碰撞标志位
    int end_flag = 0; //终点标志位
    int index; //地图序列中的索引
    float map_x,map_y;
    for(int i=global_Path_fun.size()-1;i>=0;i--){
            if(pow(pow(global_Path_fun[i].pose.position.x-global_Path_fun[0].pose.position.x,2)+
            pow(global_Path_fun[i].pose.position.x-global_Path_fun[0].pose.position.x,2)+
            pow(global_Path_fun[i].pose.position.x-global_Path_fun[0].pose.position.x,2),0.5)>length){
            aim=i;
            break;   
            }
        }
    if(aim==-1) aim=global_Path_fun.size()-1;  //无大于1的追踪点，就暂时以终点为追踪点
    aim_len =    pow(pow(global_Path_fun[aim].pose.position.x-global_Path_fun[0].pose.position.x,2)+
            pow(global_Path_fun[aim].pose.position.y-global_Path_fun[0].pose.position.y,2),0.5);
    if(aim_len<1) end_flag = 1;  //快到终点了，就不将其往外推
   
    while(aim_len>0.1){
        impact_flag = 0;
        for(float dl=0;dl<aim_len;dl=dl+resolution){  //检测碰撞
            map_x = global_Path_fun[0].pose.position.x + dl/aim_len*(global_Path_fun[aim].pose.position.x-global_Path_fun[0].pose.position.x);
            map_y = global_Path_fun[0].pose.position.y + dl/aim_len*(global_Path_fun[aim].pose.position.y-global_Path_fun[0].pose.position.y);
            index = (int)((map_x - origin_x) / resolution) + ((int)((map_y - origin_y) / resolution)) * map_width;  //地图坐标系下的点在map地图中的索引
            if(global_costmap.data[index]>60) {   //100是障碍物，99膨胀层，0-98是距离膨胀层的远近，需要留出一定的阈值防止车辆太快冲入膨胀层
                impact_flag = 1;
                break;
            }
        }
        if(impact_flag){    //检测到碰撞，折半减少跟踪点的距离
            aim = int(aim/2);
            aim_len =    pow(pow(global_Path_fun[aim].pose.position.x-global_Path_fun[0].pose.position.x,2)+
            pow(global_Path_fun[aim].pose.position.y-global_Path_fun[0].pose.position.y,2),0.5);
        }
        else{
            break;
        }
    }

    if(impact_flag = 1){  //最短跟踪点仍然碰撞
       if(end_flag ){   //若是快到终点，后面会行减速，不做处理

       }
       else{   //未快到终点，进行外推，向两边的垂直搜索可以外推的方向

       }
    }

    return aim;

}

void costmapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg){
    global_costmap = *msg;
    ROS_INFO("size_map:%d",global_costmap.data.size());
}

void pubVel(){
    vector<geometry_msgs::PoseStamped> global_Path_fun;
    geometry_msgs::Twist current_vel,new_vel;   //当前速度，新规划速度；
    geometry_msgs::PoseStamped current_pose_fun; 
    int aim=-1;  //追踪点标志物
    int stop_flag = 0;  //终点标志物
    int turn_flag = 0; //弯道标志位
    float turn_rad; //拐弯角度
    float vel_x,vel_y;
    float vel_len,vel_new_len,vel_P,len_aim;
    tf::TransformListener listener;
    tf::Quaternion startZ,endZ;
    tf::Vector3 m_vector3;//roll pitch yaw  z x y
    geometry_msgs::PointStamped map_point_start,map_point_end;
    geometry_msgs::PointStamped base_point_start,base_point_end;
    map_point_start.header.frame_id = "map";   //将这个点绑定到雷达坐标系下
    map_point_end.header.frame_id = "map";   //将这个点绑定到雷达坐标系下
       
    map_point_end.header.stamp = ros::Time();
    map_point_start.header.stamp = ros::Time();
    global_Path_fun = global_Path_;
    if(global_Path_fun.size()>1){
        current_pose_fun = current_pose;
        current_vel = current_vel_back;
        map_point_start.point.x = current_pose_fun.pose.position.x;
        map_point_start.point.y = current_pose_fun.pose.position.y;
        listener.waitForTransform("base_link","map",ros::Time(0),ros::Duration(3));//ros::Time(0)表示使用缓冲中最新的tf数据
        ROS_INFO("current_vel(x,y,w):(%f,%f,%f)",current_vel.linear.x,current_vel.linear.y,current_vel.angular.z);
        
        len_aim = pow(pow(global_Path_fun[global_Path_fun.size()-1].pose.position.x-global_Path_fun[0].pose.position.x,2)+
        pow(global_Path_fun[global_Path_fun.size()-1].pose.position.y-global_Path_fun[0].pose.position.y,2),0.5);  //计算距离终点的距离
        
        ROS_INFO("aim_distence:%f",len_aim);
        
        if(len_aim<dec_len){
        stop_flag=1;  //判断是否快到终点。
        }

        //ROS_INFO("(x,y,z_rad):(%f,%f,%f_rad)",map_point_start.point.x,map_point_start.point.y,m_vector3[0]);
    
        aim = impactTest(map_point_start,global_Path_fun,0.8);   //得到最优跟踪点 
        turn_rad = turnTest();  //利用一米前的追踪点的与自身连线的矢量和速度的矢量大致出拐弯角度的大小
        //结合最优跟踪点的距离和拐弯角度的大小判断是否提前减速
       
        

        map_point_end.point.x = global_Path_fun[aim].pose.position.x;
        map_point_end.point.y = global_Path_fun[aim].pose.position.y;
        listener.transformPoint("base_link",map_point_start,base_point_start);//将map中的点变换到base_link中去
        listener.transformPoint("base_link",map_point_end,base_point_end);//将map中的点变换到base_link中去

        vel_len = pow((pow(current_vel.linear.x,2)+pow(current_vel.linear.y,2)),0.5);
        ROS_INFO("(vel1)=(%lf)",vel_len);  //
        if(stop_flag ){
            vel_len = max(max_vel*(1/dec_len)*len_aim,vel_len*0.6f);   // 减速
        } 
        else if((a_Parameter + vel_len)<2.5) {
            //ROS_INFO("++++");
            vel_len = vel_len+a_Parameter ;  //增加速度
        }
        ROS_INFO("(vel2)=(%lf)",vel_len);


        vel_P = pow((pow(base_point_end.point.x-base_point_start.point.x,2)+pow(base_point_end.point.y-base_point_start.point.y,2)),0.5);
        if(vel_P!=0){
            vel_x = current_vel.linear.x+ P_Parameter*(base_point_end.point.x-base_point_start.point.x)*vel_len/vel_P;
            vel_y = current_vel.linear.y+ P_Parameter*(base_point_end.point.y-base_point_start.point.y)*vel_len/vel_P;
            vel_new_len = pow(pow(vel_x,2)+pow(vel_y,2),0.5);
            ROS_INFO("(vel,vel_new)=(%f,%f)",vel_len,vel_new_len);
            if(vel_new_len!=0){
                vel_x = vel_len/vel_new_len*vel_x;
                vel_y = vel_len/vel_new_len*vel_y;
                new_vel.linear.x = vel_x;
                new_vel.linear.y = vel_y;
                ROS_INFO("new_current_vel(x,y,w):(%f,%f)",new_vel.linear.x,new_vel.linear.y);
                vel_pub.publish(new_vel);  
            }
        }
     }
     /*else{
         new_vel.linear.x = 0.5* new_vel.linear.x ;
        new_vel.linear.y = 0.5*  new_vel.linear.y;
        vel_pub.publish(new_vel);  
     }*/
    return;
}


void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg){
    current_pose = *msg;
}
void pathCallback(const nav_msgs::Path::ConstPtr& msg){
    vector<geometry_msgs::PoseStamped> global_Path_fun;  //全局规划路径
    for(int i=0;i<msg->poses.size();i++){
        global_Path_fun.push_back(msg->poses[i]);
    }
    ROS_INFO("receive : %d",global_Path_fun.size());
    global_Path_ = global_Path_fun;
    pubVel();
}

void velCallback(const geometry_msgs::Twist::ConstPtr& msg){
    current_vel_back = *msg;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "new_search");  // 节点名称
    ros::NodeHandle n;

    ros::Subscriber path_sub = n.subscribe("/global_planner_node/path", 1000, pathCallback); 
    ros::Subscriber costmap_sub = n.subscribe("/global_costmap/global_costmap/costmap", 1000, costmapCallback); 
    ros::Subscriber pose_sub = n.subscribe("/amcl_pose", 1000, poseCallback); 
    ros::Subscriber vel_sub = n.subscribe("/cmd_vel", 1000, velCallback); 
    vel_pub = n.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
    ros::spin();
     
    return 0;
}
